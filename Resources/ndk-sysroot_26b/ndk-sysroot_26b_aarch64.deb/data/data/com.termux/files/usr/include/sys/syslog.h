#pragma once

/**
 * @file sys/syslog.h
 * @brief Historical synonym for `<syslog.h>`.
 *
 * New code should use `<syslog.h>` directly.
 */

#include <syslog.h>
